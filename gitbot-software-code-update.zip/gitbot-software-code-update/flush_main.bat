@echo off
rmdir /s ~temp
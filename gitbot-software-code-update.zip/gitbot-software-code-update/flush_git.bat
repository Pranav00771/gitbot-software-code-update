@echo off
cd ~temp
git remote remove origin
rmdir /s ~temp/.git
